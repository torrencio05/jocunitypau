﻿using System;


namespace Ex_03_Perimeter
{
    class Square
    {
        static void Main(string[] args)
        {
			// Console.SetWindowSize(60, 13);
			// Console.SetBufferSize(60, 13);

			int n;

			Console.WriteLine();
			Console.Write("What is the value of n (n>1)? ");
			Console.ForegroundColor = ConsoleColor.Green;
			n = Convert.ToInt32(Console.ReadLine());
			Console.WriteLine("\n");

			if (n<=1)
            {
				Console.ResetColor();
				Console.WriteLine();
				Console.WriteLine("n must be greater than 1.");
				Console.Write("press any key to exit ");
				Console.ReadKey();
				Environment.Exit(0);
			}

			Console.ForegroundColor = ConsoleColor.DarkYellow;

			/* COMPLETE THE PROGRAM */

			// TOP
			for (int i = 1; i <= n; i++)
			{
				Console.Write("1 ");
			}
			Console.WriteLine();

			// CENTER
			for (int fil = 2; fil <= n - 1; fil++)
			{
				for (int col = 1; col <= n; col++)
				{
					if (col == 1 || col == n)
					{
						Console.Write(fil + " ");
					}
					else if (col == fil)
					{
						Console.Write("0 ");
					}
					else
					{
						Console.Write("  ");
					}
				}
				Console.WriteLine();
			}

			// BOTTOM
			for (int i = 1; i <= n; i++)
			{
				Console.Write(n + " ");
			}
			Console.WriteLine();

			/****************************************************************************/

			Console.ResetColor();
			Console.SetCursorPosition(0, Console.WindowHeight - 1);
			Console.ReadKey();
		}
    }
}
