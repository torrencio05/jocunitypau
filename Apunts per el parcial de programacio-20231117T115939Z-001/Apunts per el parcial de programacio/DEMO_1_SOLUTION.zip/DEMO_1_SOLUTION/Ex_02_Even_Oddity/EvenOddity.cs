﻿using System;

namespace Ex_02_Even_Oddity
{
    class EvenOddity
    {
		public static void Main(string[] args)
		{
			Console.SetWindowSize(80, 23);
			Console.SetBufferSize(80, 23);
			
			// Random alea = new Random();
			Random alea = new ChargedDie();

			string name;
			int dieCroupier, dieGamblerOne, dieGamblerTwo;
			// if you need more variables add them here

			int numEven, numOdd; // added variables

			Console.WriteLine("A PLEASANT NIGHT AT THE CASINO");
			Console.WriteLine("------------------------------");
			Console.WriteLine();

			Console.WriteLine("Welcome to the casino!!!\n");
			Console.Write("Now gambler, please tell me your name: ");
			Console.ForegroundColor = ConsoleColor.Green;
			name = Console.ReadLine();
			Console.ResetColor();
			Console.WriteLine();

			Console.Write(name + " press any key to throw YOUR dice");
			Console.ReadKey(true); // hide the key
			Console.WriteLine("\n");
			dieGamblerOne = alea.Next(1, 7);
			dieGamblerTwo = alea.Next(1, 7);

			Console.Write("\tYOUR DICE: ");
			Console.ForegroundColor = ConsoleColor.Magenta;
			Console.WriteLine(dieGamblerOne + "   " + dieGamblerTwo);
			Console.ResetColor();
			Console.WriteLine();

			/* 
			  COMPLETE THE PROGRAM
			*/
			numEven = 0;
			numOdd = 0;
			if (dieGamblerOne % 2 == 0) numEven++;
			else numOdd++;
			if (dieGamblerTwo % 2 == 0) numEven++;
			else numOdd++;

			if (dieGamblerOne == 1 && dieGamblerTwo == 1)
			{
				// SNAKE EYES, YOU WIN
				Console.Write("CONGRATULATIONS " + name + " you win with ");
				Console.ForegroundColor = ConsoleColor.Yellow;
				Console.WriteLine("SNAKE EYES");
				Console.ResetColor();
			}
			else if (numEven == 2)
			{
				// TWO EVEN, YOU WIN
				Console.Write("CONGRATULATIONS " + name + " you win with ");
				Console.ForegroundColor = ConsoleColor.Yellow;
				Console.WriteLine("DOUBLE EVENNESS");
				Console.ResetColor();
			}
			else if (numOdd == 2)
			{
				// YOU LOSE
				Console.Write("Bad luck " + name + " you lose with ");
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("DOUBLE ODDITY");
				Console.ResetColor();
			}
			else
			{
				// croupier throws...
				Console.Write(name + " press any key and I'll throw MY die");
				Console.ReadKey(true); // hide the key
				Console.WriteLine("\n");
				dieCroupier = alea.Next(1, 7);
				Console.Write("\tMY DIE: ");
				Console.ForegroundColor = ConsoleColor.Magenta;
				Console.WriteLine(dieCroupier);
				Console.ResetColor();
				Console.WriteLine();


				if (dieCroupier % 2 == 0) numEven++;
				else numOdd++;

				if (numEven > numOdd)
				{
					// YOU WIN
					Console.Write("CONGRATULATIONS " + name + " you win with");
					Console.ForegroundColor = ConsoleColor.Yellow;
					Console.WriteLine(" AN EVEN MAJORITY");
					Console.ResetColor();
				}
				else
				{
					// YOU LOOSE
					Console.Write("Bad luck " + name + " you lose with ");
					Console.ForegroundColor = ConsoleColor.Red;
					Console.WriteLine("AN EXCESSIVE ODDITY");
					Console.ResetColor();
				}
			}

			/********************************************************************************/

			Console.SetCursorPosition(0, Console.WindowHeight - 1);
			Console.Write("Press any key to exit... ");
			Console.ReadKey();
			Environment.Exit(0);
		}
	} // MainClass ends here






	// do not modify this code.
	class ChargedDie : Random
	{
		private int[] seq = { 
							  1, 1,
							  2, 3, 4,
							  5, 6, 3,
							  1, 3,
							  4, 2
		};

		private int next;

		public ChargedDie() { next = 0; }
		public override int Next(int lower, int upper)
		{
			String line;
			int current, value;

			line = System.IO.File.ReadAllText("../../Seq.txt");
			current = Convert.ToInt32(line);
			value = seq[current];
			current = (current + 1) % seq.Length;
			System.IO.File.WriteAllText("../../Seq.txt", Convert.ToString(current));
			return value;
		}
	} // ChargedDie ends here
}
