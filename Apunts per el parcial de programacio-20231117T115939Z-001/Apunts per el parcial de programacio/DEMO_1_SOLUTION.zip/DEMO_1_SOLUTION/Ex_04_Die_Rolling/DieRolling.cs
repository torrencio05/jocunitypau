﻿using System;


namespace Ex_04_Die_Rolling
{
    class DieRolling
    {
        static void Main(string[] args)
        {
			Random alea = new Random();
			int die;
			int ones, sixes;
			int cast;
			// you're not going to need more variables than these

			//Console.SetWindowSize(80, 15);

			Console.WriteLine("-----------------------");
			Console.WriteLine("DICE, DICE, ALWAYS DICE");
			Console.WriteLine("-----------------------\n");

			/* 
				COMPLETE the program. Your iteration MUST be While-based 
			*/
			ones = 0;
			sixes = 0;
			cast = 0;

			while (!((sixes >= 2 && ones > sixes) || (cast == 20)))
			{
				die = alea.Next(1, 7);
				cast++;
				if (die == 1)
				{
					ones++;
					Console.ForegroundColor = ConsoleColor.Red;
				}
				else if (die == 6)
				{
					sixes++;
					Console.ForegroundColor = ConsoleColor.Green;
				}

				Console.Write(die + " ");
				Console.ResetColor();
			}
			// WHEN HERE
			// (sixes>=2 && ones>sixes)||(cast == 20)

			Console.WriteLine("\n");
			Console.WriteLine("ones: " + ones);
			Console.WriteLine("sixes: " + sixes);
			Console.WriteLine("times cast: " + cast);
			Console.WriteLine();
			Console.Write("TERMINATION REASON: ");
			if (sixes >= 2 && ones > sixes)
			{
				Console.WriteLine("Right number of ones and sixes achieved");
			}
			else
			{
				Console.WriteLine("die cast 20 times without success");
			}

			/*****************************************************************************/

			Console.SetCursorPosition(0, Console.WindowHeight - 1);
			Console.Write("Press any key to exit ");
			Console.ReadKey(true);
		}
    }
	
}
