﻿using System;

namespace Ex_01_Travel_Advisor
{
    class TravelAdvisor
    {
        public static void Main(string[] args)
        {
            int age, ageGroup;
            char extraversion, anxiety;
            char personalityCategory;
            String advice;
            // you're not going to need more variables that these.

            Console.SetWindowSize(80, 20);
            Console.SetBufferSize(80, 20);

            Console.WriteLine("----------------------------");
            Console.WriteLine("THE EXAM 2020 TRAVEL ADVISOR");
            Console.WriteLine("----------------------------");

            Console.WriteLine();

            Console.Write("Good day user, please tell me your age: ");
            Console.ForegroundColor = ConsoleColor.Green;
            age = Convert.ToInt32(Console.ReadLine());
            Console.ResetColor();

            if (age < 18 || age > 64)
            {
                Console.WriteLine("Sorry user. This program only gives advice if your age is between 18 and 64");
                Console.WriteLine("\n");
                Console.Write("Press any key to exit ");
                Console.ReadKey(true);
                Environment.Exit(0);  // terminate program here.
            }

            // if this point is reached, age is in [18, 64] and the program can continue...


            // get the SOCIABLE / RESERVERD (= extraversion) dimension
            Console.Write("Do yo regard yourself as SOCIABLE (S/s) or as RESERVED (R/r): ");
            Console.ForegroundColor = ConsoleColor.Green;
            extraversion = Convert.ToChar(Console.ReadLine());
            Console.ResetColor();
            while (!(extraversion == 'r' || extraversion == 'R' || extraversion == 's' || extraversion == 'S'))
            {
                Console.WriteLine("INCORRECT ANSWER...");
                Console.Write("Please enter s or S for SOCIABLE, r or R for RESERVED ");
                Console.ForegroundColor = ConsoleColor.Green;
                extraversion = Convert.ToChar(Console.ReadLine());
                Console.ResetColor();
            }
            // when this point is reached extraversion has one of these four values: 'r', 'R', 's', 'S'

            // get the CALM / ANXIOUS (= anxiety) dimension
            Console.Write("Do you consider yourseld CALM (C/c) or ANXIOUS (A/a): ");
            Console.ForegroundColor = ConsoleColor.Green;
            anxiety = Convert.ToChar(Console.ReadLine());
            Console.ResetColor();
            while (!(anxiety == 'C' || anxiety == 'c' || anxiety == 'A' || anxiety == 'a'))
            {
                Console.WriteLine("INCORRECT ANSWER...");
                Console.Write("Please enter c or C for CALM, a or A for AXIOUS ");
                Console.ForegroundColor = ConsoleColor.Green;
                anxiety = Convert.ToChar(Console.ReadLine());
                Console.ResetColor();
            }
            // when this point is reached extraversion has one of these four values: 'a', 'A', 'c', 'C'

            /* COMPLETE 1
                initialize personalityCategory with 
                'A' for sociable and calm
                'B' for sociable and anxious
                'C' for reserved and calm
                'D' for reserved and anxious
             */
            
            if (extraversion == 'S' || extraversion == 's')
            {
                if (anxiety == 'c' || anxiety == 'C')
                {
                    personalityCategory = 'A';
                }
                else
                {
                    personalityCategory = 'B';
                }
            }
            else
            {
                if (anxiety == 'c' || anxiety == 'C')
                {
                    personalityCategory = 'C';
                }
                else
                {
                    personalityCategory = 'D';
                }
            }
            /****************************************************************************/

            /* COMPLETE 2
                initialize ageGroup with
                1: age in [18, 30)
                2: age in [30,55]
                3: age in (55, 64]
             */

            
            if (age < 30)
            {
                ageGroup = 1;
            }
            else if (age <= 55)
            {
                ageGroup = 2;
            }
            else
            {
                ageGroup = 3;
            }
            /****************************************************************************/

            /* COMPLETE 3
                complete the structure that is responsible for initializing variable advice
                DO NOT use variable age, use ageGroup instead
            */

           
            switch (personalityCategory)
            {
                case 'A':
                    if (ageGroup == 1) advice = "NAMIBIA";
                    else if (ageGroup == 2) advice = "UGANDA";
                    else advice = "KENIA";
                    break;
                case 'B':
                    if (ageGroup == 1 || ageGroup == 2) advice = "ALASKA";
                    else advice = "AUSTRALIA";
                    break;
                case 'C':
                    if (ageGroup == 1) advice = "INDIA";
                    else advice = "NEPAL";
                    break;
                case 'D':
                    advice = "JAPAN";
                    break;
                default:
                    advice = "???????";
                    break;
            } // end of switch 
            /****************************************************************************/

            // DO NOT WRITE ANY CODE BEYOND THIS POINT

            Console.WriteLine();
            Console.Write("Well, your personality category is: ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(personalityCategory);
            Console.ResetColor();
            Console.Write("And your age group is: ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(ageGroup);
            Console.ResetColor();

            Console.WriteLine();
            Console.Write("According to all this my advice is that you travel to ");
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.Write(advice); // here, advice is written
            Console.ResetColor();

            Console.SetCursorPosition(0, Console.WindowHeight - 1);
            Console.Write("Press any key to exit ");
            Console.ReadKey(true);

        } // end of main
    }
}
