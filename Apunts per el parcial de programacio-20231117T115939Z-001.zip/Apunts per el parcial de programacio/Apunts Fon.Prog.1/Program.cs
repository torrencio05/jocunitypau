﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apunts_Fon.Prog._1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool a;                  // assignacó de vriable per a algo que és "true" o "false"
            int b;                   // assignacó de vriable per a nombres enters
            double c;                // assignacó de vriable per a nombres reals (decimals)
            string d;                // assignacó de vriable per a cadenes de lletres o caràcters
            char                     // assignacó de vriable per a nomès 1 caracter

                // OR = true menys cuan tot false
                // AND = false menys quan tot true
                || = // condicional OR
                && = // condicional AND
                ! = // negació
                = //assignació
                == // igual


                if // condicional
                switch // condicional
                for // iteració (per quan saps quantes vegades)
                while // iteració (si no saps quantes vegades)
        }
    }
}
